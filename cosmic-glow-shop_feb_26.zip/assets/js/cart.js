
const modalOverlay = document.getElementById('modal-overlay');
const modalContainer = document.getElementById('modal-container');
const cartBtn = document.getElementById('cart-btn');
const cartBtn2 = document.getElementById('cart-btn2');
const cartCounter = document.getElementById('cart-counter');
const cartCounter2 = document.getElementById('cart-counter2');

function formatPrice(price) {
    return price.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ".");
}

function displayCart(cart) {
    modalContainer.innerHTML = "";
    modalOverlay.style.display = "block";
    modalContainer.style.display = "block";

    const modalHeader = document.createElement("div");
    modalHeader.className = "modal-header";

    const modalTitle = document.createElement("div");
    modalTitle.innerHTML = "TUS COMPRAS...</i>";
    modalTitle.className = "modal-title";

    const modalClose = document.createElement("h2");
    modalClose.innerHTML = `<i class="fa-solid fa-x"></i>`;
    modalClose.className = "modal-close";

    modalHeader.append(modalTitle, modalClose);
    modalContainer.append(modalHeader);

    modalClose.addEventListener('click', () => {
        modalOverlay.style.display = "none";
        modalContainer.style.display = "none";
    });

    if (cart.length > 0) {
        cart.forEach((product) => {
            const modalBody = document.createElement("div");
            modalBody.className = "modal-body";
            modalBody.innerHTML = `
                    <div class="product">
                        <img src="${product.img}" class="product-img" alt="" data-productId="${product.id}">
                        <div class="product-info">
                            <h4>${product.proName}</h4>
                            <div class="quantity">
                                <span class="quantity-btn-input">Unidades: </span>
                                <span class="quantity-btn-decrease">-</span>
                                <span class="quantity-btn-input">${product.quanty}</span>
                                <span class="quantity-btn-increase">+</span>
                            </div>
                            <div class="price">
                                <div class="price">Total: $${formatPrice(product.price * product.quanty)}<div class="price delete-product"><i class="fas fa-trash"></i></div></div>
                            </div>
                        </div>
                    </div>`;

            modalContainer.append(modalBody);

            const productImg = modalBody.querySelector('.product-img');

            productImg.style.cursor = 'pointer';
            productImg.addEventListener('click', () => {
                navigateToProductDetail(product.id);
            });

            const decrease = modalBody.querySelector('.quantity-btn-decrease');
            decrease.addEventListener('click', () => {
                if (product.quanty !== 1) {
                    product.quanty--;
                    displayCart(cart);
                    displayCartCounters(cart);
                }
            });

            const increase = modalBody.querySelector('.quantity-btn-increase');
            increase.addEventListener('click', () => {
                product.quanty++;
                displayCart(cart);
                displayCartCounters(cart);
            });

            const deleteProduct = modalBody.querySelector('.delete-product');
            deleteProduct.addEventListener('click', () => {
                deleteCartProduct(product.id, cart);
            });
        });

        const total = cart.reduce((acc, el) => acc + el.price * el.quanty, 0);
        const modalTotal = document.createElement("div");
        modalTotal.className = "modal-total";
        modalTotal.innerHTML = `<div class="total-price">SubTotal: $${formatPrice(total)}</div>`;
        modalContainer.append(modalTotal);

        const modalFooter = document.createElement("div");
        modalFooter.className = "modal-footer";
        modalFooter.innerHTML = `
                <button class="btn-primary checkout-btn">Confirmar Pedido</button>
                <button class="btn-primary cart-btn">Ir a Carrito</button>`;

        modalContainer.append(modalFooter);

        const checkoutButton = modalFooter.querySelector(".checkout-btn");
        checkoutButton.addEventListener('click', () => handleCheckout(cart));

        const cartButton = modalFooter.querySelector(".cart-btn");
        cartButton.addEventListener('click', () => navigateToCart());

    } else {
        const modalText = document.createElement("h2");
        modalText.className = "modal-body";
        modalText.innerHTML = "No tienes Articulos en tu Carrito!";
        modalContainer.append(modalText);
    }

    saveCartToStorage(cart);
}

function navigateToCart() {
    window.location.href = "carro.html";
}

cartBtn.addEventListener('click', function () {
    const cart = loadCartFromStorage();
    displayCart(cart);
    window.scrollTo({
        top: 0,
        behavior: 'smooth'
    });
});
cartBtn2.addEventListener('click', function () {
    const cart = loadCartFromStorage();
    displayCart(cart);
    window.scrollTo({
        top: 0,
        behavior: 'smooth'
    });
});


function deleteCartProduct(id, cart) {
    const findId = cart.findIndex((element) => element.id === id);
    cart.splice(findId, 1);
    displayCart(cart);
    displayCartCounters(cart);
}

function loadCartFromStorage() {
    const cartString = localStorage.getItem('cart');
    return cartString ? JSON.parse(cartString) : [];
}

function saveCartToStorage(cart) {
    localStorage.setItem('cart', JSON.stringify(cart));
}

function displayCartCounters(cart) {
    const cartLength = cart.reduce((sum, el) => sum + el.quanty, 0);
    const counters = [cartCounter, cartCounter2];

    counters.forEach((counter) => {
        if (cartLength > 0) {
            counter.style.display = "block";
            counter.innerText = cartLength;
        } else {
            counter.style.display = "none";
        }
    });
}

function handleCheckout(cart) {
    const resumenPedido = cart.map(producto => `${producto.proName}: $${formatPrice(producto.price * producto.quanty)}  `).join('-');
    const total = cart.reduce((acc, el) => acc + el.price * el.quanty, 0);
    const mensajePedido = `¡Hola! Me gustaría realizar el pedido con los siguientes productos:${resumenPedido}Total Pedido: $${formatPrice(total)}`;
    const telefono = '+573214076057';
    const mensajeURL = `https://wa.me/${telefono}/?text=${encodeURIComponent(mensajePedido)}`;
    window.open(mensajeURL);
}

function navigateToProductDetail(productId) {
    // Redireccionar a la página de detalle del producto con el ID proporcionado
    window.location.href = `detalle_producto.html?id=${productId}`;
}

